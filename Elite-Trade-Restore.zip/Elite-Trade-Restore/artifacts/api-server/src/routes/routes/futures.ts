/**
 * futures.ts — Perp Futures trading endpoints (Phase 2).
 *
 * Isolated from the spot manual-trading path on purpose: this file does not
 * import lib/bot.ts's execution functions and does not touch the spot risk
 * engine, execution queue, or portfolio registry. It reads the currently
 * loaded Gate.io credentials via bot.getBotExchangeCreds() (an existing,
 * unmodified read-only getter) and drives them through the new, separate
 * gateioFuturesExchange.ts driver.
 *
 * Every route fails closed: if capability can't be confirmed, or an
 * exchange call throws, we return { ok:false } — never a fabricated success.
 *
 * ⚠️ UNVERIFIED — written and reviewed but never run against a live Gate.io
 * account (no network in the environment that produced this). Test each
 * route against paper-mode futures-enabled keys before enabling in the UI.
 */
import { Router, type Request, type Response } from "express";
import * as bot from "../../lib/bot";
import * as futuresExchange from "../../services/gateioFuturesExchange";
import { publishEvent } from "../../lib/eventBus";
import { logger } from "../../lib/logger";
import { db, ordersTable } from "@workspace/db";
import { and, desc, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";

const router = Router();

function creds() {
  const c = bot.getBotExchangeCreds();
  return { apiKey: c.apiKey, secret: c.secret, password: c.password, paper: c.paper };
}

// ─── GET /api/futures/capability ───────────────────────────────────────────

router.get("/futures/capability", async (_req: Request, res: Response): Promise<void> => {
  try {
    if (!bot.getBotHasKeys()) {
      res.json({ ok: true, supported: false, reason: "No Gate.io API keys connected." });
      return;
    }
    const result = await futuresExchange.checkFuturesCapability(creds());
    res.json({ ok: true, ...result });
  } catch (e) {
    logger.error({ err: e }, "futures.capability failed");
    res.json({ ok: true, supported: false, reason: e instanceof Error ? e.message : String(e) });
  }
});

// ─── GET /api/futures/positions ────────────────────────────────────────────

router.get("/futures/positions", async (_req: Request, res: Response): Promise<void> => {
  try {
    if (!bot.getBotHasKeys()) { res.json({ ok: true, positions: [] }); return; }
    const positions = await futuresExchange.fetchPositions(creds());
    res.json({ ok: true, positions });
  } catch (e) {
    res.status(502).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});

// ─── GET /api/futures/funding-rate/:symbol ─────────────────────────────────

router.get("/futures/funding-rate/:symbol", async (req: Request, res: Response): Promise<void> => {
  const symbol = String(req.params["symbol"] ?? "").toUpperCase();
  if (!symbol) { res.status(400).json({ ok: false, error: "symbol is required" }); return; }
  const result = await futuresExchange.fetchFundingRate(symbol);
  if (!result) { res.status(502).json({ ok: false, error: "Could not fetch funding rate" }); return; }
  res.json({ ok: true, ...result });
});

// ─── GET /api/futures/orders ────────────────────────────────────────────────

router.get("/futures/orders", async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.user?.uid;
    if (!userId) { res.json({ ok: true, orders: [] }); return; }
    const rows = await db
      .select()
      .from(ordersTable)
      .where(and(eq(ordersTable.market, "futures"), eq(ordersTable.userId, userId)))
      .orderBy(desc(ordersTable.createdAt))
      .limit(100);
    res.json({ ok: true, orders: rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});

// ─── POST /api/futures/leverage ────────────────────────────────────────────

router.post("/futures/leverage", async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body ?? {};
    const symbol = String(body.symbol ?? "").toUpperCase();
    const leverage = Number(body.leverage);
    const marginMode = body.marginMode === "cross" ? "cross" : "isolated";

    if (!symbol) { res.status(400).json({ ok: false, error: "symbol is required" }); return; }
    if (!bot.getBotHasKeys()) { res.status(400).json({ ok: false, error: "No Gate.io API keys connected." }); return; }

    const cap = await futuresExchange.checkFuturesCapability(creds());
    if (!cap.supported) { res.status(400).json({ ok: false, error: cap.reason ?? "Futures not supported for this account." }); return; }

    const result = await futuresExchange.setLeverage(creds(), symbol, leverage, marginMode);
    if (!result.success) { res.status(400).json({ ok: false, error: result.error }); return; }
    res.json({ ok: true, symbol, leverage, marginMode });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});

// ─── POST /api/futures/order ───────────────────────────────────────────────

/**
 * Body: { symbol, positionSide: "long"|"short", orderType: "MARKET"|"LIMIT",
 *         limitPrice?, quantity, leverage, marginMode: "isolated"|"cross" }
 *
 * positionSide="long" + open  → buy
 * positionSide="short" + open → sell
 * (Closing goes through /futures/close, not this route.)
 */
router.post("/futures/order", async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body ?? {};
    const symbol = String(body.symbol ?? "").trim().toUpperCase();
    const positionSide = body.positionSide === "short" ? "short" : "long";
    const orderType = String(body.orderType ?? "MARKET").toUpperCase();
    const limitPrice = body.limitPrice != null ? Number(body.limitPrice) : undefined;
    const quantity = Number(body.quantity);
    const leverage = Number(body.leverage ?? 1);
    const marginMode = body.marginMode === "cross" ? "cross" : "isolated";
    const tpPrice = body.tpPrice != null ? Number(body.tpPrice) : undefined;
    const slPrice = body.slPrice != null ? Number(body.slPrice) : undefined;

    if (!symbol || !/^[A-Z0-9_/:-]+$/.test(symbol)) {
      res.status(400).json({ ok: false, error: "A valid trading symbol is required" }); return;
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      res.status(400).json({ ok: false, error: "quantity must be > 0" }); return;
    }
    if (orderType === "LIMIT" && (!limitPrice || limitPrice <= 0)) {
      res.status(400).json({ ok: false, error: "limitPrice is required for LIMIT orders" }); return;
    }
    if (!Number.isFinite(leverage) || leverage < 1 || leverage > 125) {
      res.status(400).json({ ok: false, error: "leverage must be between 1 and 125" }); return;
    }
    if (!bot.getBotHasKeys()) {
      res.status(400).json({ ok: false, error: "No Gate.io API keys connected." }); return;
    }

    const cap = await futuresExchange.checkFuturesCapability(creds());
    if (!cap.supported) {
      res.status(400).json({ ok: false, error: cap.reason ?? "This Gate.io key does not have futures trading enabled." });
      return;
    }

    const side = positionSide === "long" ? "buy" : "sell";
    const result = await futuresExchange.createOrder(creds(), {
      symbol,
      side,
      type: orderType === "LIMIT" ? "limit" : "market",
      amount: quantity,
      price: limitPrice,
      leverage,
      marginMode,
      tpPrice,
      slPrice,
    });

    if (!result.success) { res.status(400).json({ ok: false, error: result.error }); return; }

    const userId = req.user?.uid ?? null;
    const orderId = randomUUID();
    try {
      await db.insert(ordersTable).values({
        orderId,
        userId,
        symbol,
        side: side === "buy" ? "BUY" : "SELL",
        orderType: orderType === "LIMIT" ? "LIMIT" : "MARKET",
        limitPrice: limitPrice != null ? String(limitPrice) : null,
        quantity: String(quantity),
        remainingQuantity: String(quantity),
        status: orderType === "LIMIT" ? "open" : "filled",
        source: "MANUAL",
        exchange: "gateio",
        exchangeOrderId: result.orderId,
        isPaper: Boolean(creds().paper),
        market: "futures",
        positionSide,
        leverage,
        marginMode,
        filledAt: orderType === "LIMIT" ? null : new Date(),
      });
    } catch (dbErr) {
      // Order already went to the exchange — never mask a real fill behind a DB error.
      logger.error({ err: dbErr, orderId }, "futures.order: DB write failed after exchange success");
    }

    publishEvent({
      type: "order:created",
      payload: { action: "futures_order_placed", symbol, positionSide, orderId },
      ts: new Date().toISOString(),
    });

    res.json({ ok: true, action: "futures_order", symbol, positionSide, leverage, marginMode, ...result });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});

// ─── POST /api/futures/close ───────────────────────────────────────────────

router.post("/futures/close", async (req: Request, res: Response): Promise<void> => {
  try {
    const body = req.body ?? {};
    const symbol = String(body.symbol ?? "").trim().toUpperCase();
    const positionSide = body.positionSide === "short" ? "short" : "long";
    const amount = Number(body.amount);

    if (!symbol) { res.status(400).json({ ok: false, error: "symbol is required" }); return; }
    if (!Number.isFinite(amount) || amount <= 0) {
      res.status(400).json({ ok: false, error: "amount must be > 0" }); return;
    }
    if (!bot.getBotHasKeys()) { res.status(400).json({ ok: false, error: "No Gate.io API keys connected." }); return; }

    const result = await futuresExchange.closePosition(creds(), symbol, positionSide, amount);
    if (!result.success) { res.status(400).json({ ok: false, error: result.error }); return; }

    // NOTE: no local positionsTable row is written/updated for futures yet —
    // there is no futures position registry populating it on open, so writing
    // a "closed" row here without a matching "open" row would be misleading.
    // GET /api/futures/positions reads live from the exchange, which is the
    // correct source of truth until that registry is built (see report).

    publishEvent({
      type: "position:update",
      payload: { action: "futures_manual_close", symbol, positionSide },
      ts: new Date().toISOString(),
    });

    res.json({ ok: true, action: "futures_close", symbol, positionSide, ...result });
  } catch (e) {
    res.status(500).json({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }
});

export default router;
