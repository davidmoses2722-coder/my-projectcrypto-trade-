/**
 * gateioFuturesExchange — Gate.io USDT-margined Perpetual Futures CCXT driver.
 *
 * Deliberately a SEPARATE file from gateioExchange.ts (spot). Nothing here is
 * imported by lib/bot.ts or manual-trading.ts, so the existing spot execution
 * path is byte-for-byte unchanged by this file's existence.
 *
 * Gate.io USDT-M perpetual swaps are addressed in CCXT's unified symbol form
 * "BASE/QUOTE:SETTLE", e.g. "BTC/USDT:USDT".
 *
 * ⚠️ UNVERIFIED AGAINST A LIVE GATE.IO ACCOUNT
 * This was written and reviewed but never executed — the sandbox that
 * produced it has no network access. Before enabling this in production:
 *   1. Run checkFuturesCapability() against a real (ideally paper/testnet)
 *      Gate.io futures-enabled key and confirm it returns supported: true.
 *   2. Place one small real order on paper mode and confirm the response
 *      shape (liquidationPrice, markPrice field names) matches what's
 *      assumed below — Gate.io's CCXT unified fields can vary by account
 *      type and CCXT version.
 */

import ccxt from "ccxt";
import type { Exchange } from "ccxt";
import { logger } from "../lib/logger";

export interface GateioCreds {
  apiKey: string;
  secret: string;
  password?: string;
  paper?: boolean;
}

export interface FuturesCapabilityResult {
  supported: boolean;
  reason?: string;
  balanceUsdt?: number;
}

export interface FuturesPositionResult {
  symbol: string;
  side: "long" | "short";
  contracts: number;
  entryPrice: number;
  markPrice: number;
  liquidationPrice: number | null;
  leverage: number;
  marginMode: "isolated" | "cross";
  initialMargin: number;
  unrealizedPnl: number;
  realizedPnl: number;
  raw?: unknown;
}

export interface FuturesOrderInput {
  symbol: string;
  side: "buy" | "sell"; // buy = open/add long or close short; sell = open/add short or close long
  type: "market" | "limit";
  amount: number; // in contracts/base units
  price?: number;
  reduceOnly?: boolean;
  leverage?: number;
  marginMode?: "isolated" | "cross";
  clientOrderId?: string;
  tpPrice?: number;
  slPrice?: number;
}

export interface FuturesOrderResult {
  success: boolean;
  orderId: string | null;
  price: number | null;
  amount: number | null;
  status?: string;
  filled?: number;
  raw?: unknown;
  error?: string;
}

export interface FundingRateResult {
  symbol: string;
  fundingRate: number;
  nextFundingTime: number | null;
  markPrice: number | null;
}

// ─── CCXT instance cache (separate from spot cache) ─────────────────────────

const cache = new Map<string, Exchange>();

function fingerprint(creds: GateioCreds): string {
  return `gateio-futures|${creds.apiKey}|${creds.paper ? "paper" : "live"}`;
}

function toFuturesSymbol(raw: string): string {
  if (raw.includes(":")) return raw; // already unified futures form
  const base = raw.includes("/") ? raw : toSpotSymbol(raw);
  const [b, q] = base.split("/");
  if (!b || !q) return raw;
  return `${b}/${q}:${q}`; // USDT-margined perpetual, e.g. BTC/USDT:USDT
}

function toSpotSymbol(raw: string): string {
  if (raw.includes("/")) return raw;
  const quotes = ["USDT", "USDC", "USD"];
  for (const q of quotes) {
    if (raw.endsWith(q)) {
      const b = raw.slice(0, -q.length);
      if (b) return `${b}/${q}`;
    }
  }
  return raw;
}

function safeError(e: unknown): string {
  if (e instanceof Error) return e.message;
  try { return JSON.stringify(e); } catch { return String(e); }
}

/** Return a cached (or new) authenticated CCXT instance in "swap" (futures) mode. */
export function connect(creds: GateioCreds): Exchange {
  const key = fingerprint(creds);
  const cached = cache.get(key);
  if (cached) return cached;

  const ex = new ccxt.gate({
    apiKey: creds.apiKey,
    secret: creds.secret,
    password: creds.password,
    enableRateLimit: true,
    timeout: 15_000,
    options: { defaultType: "swap", defaultSettle: "usdt" },
  });

  if (creds.paper) {
    ex.headers = { ...(ex.headers ?? {}), "x-simulated-trading": "1" };
  }

  cache.set(key, ex);
  return ex;
}

export function evict(creds: GateioCreds): void {
  cache.delete(fingerprint(creds));
}

// ─── checkFuturesCapability() ────────────────────────────────────────────────

/**
 * Read-only probe: does this key have futures trading permission on Gate.io?
 * This is the gate the frontend must call before showing the Futures tab as
 * enabled. On ANY doubt, returns supported: false — never fail open.
 */
export async function checkFuturesCapability(creds: GateioCreds): Promise<FuturesCapabilityResult> {
  try {
    const ex = connect(creds);
    const bal = await ex.fetchBalance({ type: "swap" });
    const free = (bal.free as unknown as Record<string, number>) ?? {};
    const balanceUsdt = Number(free["USDT"] ?? 0);
    return { supported: true, balanceUsdt };
  } catch (e) {
    const msg = safeError(e);
    logger.warn({ err: e }, "gateioFuturesExchange.checkFuturesCapability: not supported");
    return { supported: false, reason: msg };
  }
}

// ─── fetchPositions() ────────────────────────────────────────────────────────

export async function fetchPositions(creds: GateioCreds, symbol?: string): Promise<FuturesPositionResult[]> {
  const ex = connect(creds);
  const symbols = symbol ? [toFuturesSymbol(symbol)] : undefined;
  const raw = await ex.fetchPositions(symbols);
  return raw
    .filter((p: import("ccxt").Position) => Number(p.contracts ?? 0) !== 0)
    .map((p: import("ccxt").Position) => ({
      symbol: String(p.symbol ?? ""),
      side: (p.side === "short" ? "short" : "long") as "long" | "short",
      contracts: Number(p.contracts ?? 0),
      entryPrice: Number(p.entryPrice ?? 0),
      markPrice: Number(p.markPrice ?? 0),
      liquidationPrice: p.liquidationPrice != null ? Number(p.liquidationPrice) : null,
      leverage: Number(p.leverage ?? 1),
      marginMode: (p.marginMode === "cross" ? "cross" : "isolated") as "isolated" | "cross",
      initialMargin: Number(p.initialMargin ?? 0),
      unrealizedPnl: Number(p.unrealizedPnl ?? 0),
      realizedPnl: Number((p as unknown as { realizedPnl?: number }).realizedPnl ?? 0),
      raw: p,
    }));
}

// ─── setLeverage() ────────────────────────────────────────────────────────────

export async function setLeverage(
  creds: GateioCreds,
  symbol: string,
  leverage: number,
  marginMode: "isolated" | "cross" = "isolated",
): Promise<{ success: boolean; error?: string }> {
  if (!Number.isFinite(leverage) || leverage < 1 || leverage > 125) {
    return { success: false, error: "leverage must be between 1 and 125" };
  }
  try {
    const ex = connect(creds);
    const fSymbol = toFuturesSymbol(symbol);
    try {
      await ex.setMarginMode(marginMode, fSymbol);
    } catch (marginErr) {
      // Some Gate.io accounts default to one mode and reject redundant switches —
      // log but don't hard-fail the whole leverage call on this alone.
      logger.warn({ err: marginErr, symbol, marginMode }, "gateioFuturesExchange.setLeverage: setMarginMode warning");
    }
    await ex.setLeverage(leverage, fSymbol);
    return { success: true };
  } catch (e) {
    logger.error({ err: e, symbol, leverage }, "gateioFuturesExchange.setLeverage failed");
    return { success: false, error: safeError(e) };
  }
}

// ─── fetchFundingRate() ───────────────────────────────────────────────────────

export async function fetchFundingRate(symbol: string): Promise<FundingRateResult | null> {
  try {
    const ex = new ccxt.gate({ enableRateLimit: true, timeout: 10_000, options: { defaultType: "swap", defaultSettle: "usdt" } });
    const r = await ex.fetchFundingRate(toFuturesSymbol(symbol));
    return {
      symbol,
      fundingRate: Number(r.fundingRate ?? 0),
      nextFundingTime: r.fundingTimestamp ?? null,
      markPrice: r.markPrice != null ? Number(r.markPrice) : null,
    };
  } catch (e) {
    logger.warn({ err: e, symbol }, "gateioFuturesExchange.fetchFundingRate failed");
    return null;
  }
}

// ─── createOrder() ────────────────────────────────────────────────────────────

/**
 * Open/add-to/close/reduce a futures position.
 * side="buy" opens or increases a long (or reduces/closes a short if reduceOnly).
 * side="sell" opens or increases a short (or reduces/closes a long if reduceOnly).
 */
export async function createOrder(
  creds: GateioCreds,
  input: FuturesOrderInput,
): Promise<FuturesOrderResult> {
  if (input.amount <= 0) {
    return { success: false, orderId: null, price: null, amount: null, error: "amount must be > 0" };
  }
  if (input.type === "limit" && (input.price == null || input.price <= 0)) {
    return { success: false, orderId: null, price: null, amount: null, error: "price required for limit orders" };
  }

  try {
    const ex = connect(creds);
    const symbol = toFuturesSymbol(input.symbol);

    if (input.leverage != null) {
      const lev = await setLeverage(creds, symbol, input.leverage, input.marginMode ?? "isolated");
      if (!lev.success) {
        return { success: false, orderId: null, price: null, amount: null, error: `leverage rejected: ${lev.error}` };
      }
    }

    const params: Record<string, unknown> = {};
    if (input.reduceOnly) params["reduceOnly"] = true;
    if (input.clientOrderId) params["clientOrderId"] = input.clientOrderId;
    if (input.tpPrice != null && input.tpPrice > 0) {
      params["tpTriggerPx"] = String(input.tpPrice.toFixed(8));
      params["tpOrdPx"] = "-1";
    }
    if (input.slPrice != null && input.slPrice > 0) {
      params["slTriggerPx"] = String(input.slPrice.toFixed(8));
      params["slOrdPx"] = "-1";
    }

    const order = await ex.createOrder(symbol, input.type, input.side, input.amount, input.price, params);

    logger.info(
      { symbol: input.symbol, side: input.side, type: input.type, reduceOnly: input.reduceOnly, orderId: order.id },
      "gateioFuturesExchange.createOrder: submitted",
    );

    return {
      success: true,
      orderId: String(order.id ?? ""),
      price: order.price ?? order.average ?? input.price ?? null,
      amount: order.amount ?? input.amount,
      status: order.status,
      filled: order.filled,
      raw: order,
    };
  } catch (e) {
    logger.error({ err: e, symbol: input.symbol, side: input.side }, "gateioFuturesExchange.createOrder failed");
    return { success: false, orderId: null, price: null, amount: null, error: safeError(e) };
  }
}

// ─── closePosition() ──────────────────────────────────────────────────────────

export async function closePosition(
  creds: GateioCreds,
  symbol: string,
  side: "long" | "short",
  amount: number,
): Promise<FuturesOrderResult> {
  // Closing a long = sell reduceOnly; closing a short = buy reduceOnly.
  return createOrder(creds, {
    symbol,
    side: side === "long" ? "sell" : "buy",
    type: "market",
    amount,
    reduceOnly: true,
  });
}
