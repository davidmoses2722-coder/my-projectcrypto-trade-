/**
 * FuturesTerminal — BingX-style Perp Futures panel.
 *
 * Deliberately isolated from ManualTradingCenter's spot logic: separate
 * component, separate state, separate endpoints (/api/futures/*). Nothing
 * here is imported by the spot code path.
 *
 * Every control that cannot execute yet (because the connected Gate.io key
 * lacks futures permission, or because no keys are connected) is rendered
 * visible but disabled, with the exact reason shown — never hidden, never
 * silently faked.
 */
import { useEffect, useState, useCallback, useMemo } from "react";
import { AlertTriangle, CheckCircle2, Clock3, TrendingUp } from "lucide-react";
import type { CoinPrice } from "../types/crypto";
import { SERVER_URL } from "../config/urls";
import { useSSE } from "../hooks/useSSE";

type PositionSide = "long" | "short";
type MarginMode = "isolated" | "cross";
type OrderType = "MARKET" | "LIMIT";

interface FuturesPosition {
  symbol: string;
  side: PositionSide;
  contracts: number;
  entryPrice: number;
  markPrice: number;
  liquidationPrice: number | null;
  leverage: number;
  marginMode: MarginMode;
  initialMargin: number;
  unrealizedPnl: number;
  realizedPnl: number;
}

interface FuturesOrderRow {
  orderId: string;
  symbol: string;
  side: string;
  orderType: string;
  limitPrice: string | null;
  quantity: string;
  status: string;
  positionSide: string | null;
  leverage: number | null;
  createdAt: string;
}

interface Capability {
  supported: boolean;
  reason?: string;
  balanceUsdt?: number;
}

interface Props {
  symbol: string;
  prices: CoinPrice[];
  isPaper: boolean;
  onRefreshStatus?: () => Promise<void>;
}

const authHeaders = (): Record<string, string> => {
  const token = localStorage.getItem("pcb_jwt");
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const fmt = (n: number, dp = 2) => n.toLocaleString(undefined, { minimumFractionDigits: dp, maximumFractionDigits: dp });

const LEVERAGE_PRESETS = [5, 10, 20, 25, 50, 75, 100, 125];

export function FuturesTerminal({ symbol, prices, isPaper, onRefreshStatus }: Props) {
  const base = symbol.split("_")[0] ?? symbol.split("/")[0] ?? symbol;
  const displaySymbol = symbol.includes("/") ? symbol : symbol.replace("_", "/");
  const coinPrice = prices.find(p => p.symbol === base);
  const livePrice = coinPrice?.price ?? 0;

  const [cap, setCap] = useState<Capability | null>(null);
  const [capLoading, setCapLoading] = useState(true);

  const fetchCapability = useCallback(async () => {
    setCapLoading(true);
    try {
      const r = await fetch(`${SERVER_URL}/api/futures/capability`, { headers: authHeaders() as HeadersInit });
      const d = await r.json() as Capability & { ok?: boolean };
      setCap({ supported: Boolean(d.supported), reason: d.reason, balanceUsdt: d.balanceUsdt });
    } catch (e) {
      setCap({ supported: false, reason: e instanceof Error ? e.message : "Could not reach futures API" });
    } finally {
      setCapLoading(false);
    }
  }, []);

  useEffect(() => { void fetchCapability(); }, [fetchCapability]);

  const canTrade = cap?.supported === true;
  const balance = cap?.balanceUsdt ?? 0;

  const [positionSide, setPositionSide] = useState<PositionSide>("long");
  const [marginMode, setMarginMode] = useState<MarginMode>("isolated");
  const [leverage, setLeverage] = useState(20);
  const [orderType, setOrderType] = useState<OrderType>("MARKET");
  const [limitPrice, setLimitPrice] = useState(0);
  const [amountUsdt, setAmountUsdt] = useState(0);
  const [showTpSl, setShowTpSl] = useState(true);
  const [tpTrigger, setTpTrigger] = useState(0);
  const [slTrigger, setSlTrigger] = useState(0);
  const [busy, setBusy] = useState(false);
  const [flash, setFlash] = useState<{ ok: boolean; text: string } | null>(null);

  const notionalQty = useMemo(() => {
    if (livePrice <= 0) return 0;
    return (amountUsdt * leverage) / livePrice;
  }, [amountUsdt, leverage, livePrice]);

  const marginRequired = amountUsdt;

  const setPctOfBalance = (pct: number) => {
    if (balance <= 0) return;
    setAmountUsdt(Math.round((balance * pct) / 100));
  };

  const showFlash = (ok: boolean, text: string) => {
    setFlash({ ok, text });
    setTimeout(() => setFlash(null), 5000);
  };

  const [bottomTab, setBottomTab] = useState<"positions" | "orders">("positions");
  const [positions, setPositions] = useState<FuturesPosition[]>([]);
  const [posLoading, setPosLoading] = useState(false);
  const [orders, setOrders] = useState<FuturesOrderRow[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [closingSymbol, setClosingSymbol] = useState<string | null>(null);

  const fetchPositions = useCallback(async () => {
    if (!canTrade) { setPositions([]); return; }
    setPosLoading(true);
    try {
      const r = await fetch(`${SERVER_URL}/api/futures/positions`, { headers: authHeaders() as HeadersInit });
      const d = await r.json() as { ok?: boolean; positions?: FuturesPosition[] };
      setPositions(d.positions ?? []);
    } catch { /* leave last-known list */ }
    finally { setPosLoading(false); }
  }, [canTrade]);

  const fetchOrders = useCallback(async () => {
    setOrdersLoading(true);
    try {
      const r = await fetch(`${SERVER_URL}/api/futures/orders`, { headers: authHeaders() as HeadersInit });
      const d = await r.json() as { ok?: boolean; orders?: FuturesOrderRow[] };
      setOrders(d.orders ?? []);
    } catch { /* leave last-known list */ }
    finally { setOrdersLoading(false); }
  }, []);

  useEffect(() => { void fetchPositions(); }, [fetchPositions]);
  useEffect(() => { void fetchOrders(); }, [fetchOrders]);
  useEffect(() => {
    if (!canTrade) return;
    const id = setInterval(() => { void fetchPositions(); }, 8000);
    return () => clearInterval(id);
  }, [canTrade, fetchPositions]);

  const submitOrder = async () => {
    if (!canTrade) return;
    setBusy(true);
    try {
      const body: Record<string, unknown> = {
        symbol: displaySymbol,
        positionSide,
        orderType,
        quantity: notionalQty,
        leverage,
        marginMode,
      };
      if (orderType === "LIMIT") body["limitPrice"] = limitPrice;
      if (showTpSl && tpTrigger > 0) body["tpPrice"] = tpTrigger;
      if (showTpSl && slTrigger > 0) body["slPrice"] = slTrigger;

      const r = await fetch(`${SERVER_URL}/api/futures/order`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() } as HeadersInit,
        body: JSON.stringify(body),
      });
      const d = await r.json() as { ok?: boolean; error?: string };
      if (!d.ok) throw new Error(d.error ?? "Order failed");
      showFlash(true, `${positionSide === "long" ? "Open Long" : "Open Short"} submitted.`);
      setAmountUsdt(0);
      void fetchPositions();
      void fetchOrders();
      void onRefreshStatus?.();
    } catch (e) {
      showFlash(false, e instanceof Error ? e.message : "Order failed");
    } finally {
      setBusy(false);
    }
  };

  const closePosition = async (pos: FuturesPosition) => {
    setClosingSymbol(pos.symbol);
    try {
      const r = await fetch(`${SERVER_URL}/api/futures/close`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() } as HeadersInit,
        body: JSON.stringify({ symbol: pos.symbol, positionSide: pos.side, amount: pos.contracts }),
      });
      const d = await r.json() as { ok?: boolean; error?: string };
      if (!d.ok) throw new Error(d.error ?? "Close failed");
      showFlash(true, `Closed ${pos.symbol}.`);
      void fetchPositions();
      void fetchOrders();
      void onRefreshStatus?.();
    } catch (e) {
      showFlash(false, e instanceof Error ? e.message : "Close failed");
    } finally {
      setClosingSymbol(null);
    }
  };

  useSSE((event) => {
    if (
      event.type === "position:open" ||
      event.type === "position:close" ||
      event.type === "position:update" ||
      event.type === "order:created" ||
      event.type === "order:update"
    ) {
      void fetchCapability();
      void fetchPositions();
      void fetchOrders();
    }
  });

  return (
    <div className="flex flex-1 min-h-0 overflow-hidden flex-col">
      {!capLoading && !canTrade && (
        <div className="flex items-start gap-2.5 mx-4 mt-3 px-3 py-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[11px]">
          <AlertTriangle size={13} className="shrink-0 mt-0.5" />
          <div>
            <div className="font-black uppercase tracking-wide mb-0.5">Futures trading unavailable</div>
            <div className="text-amber-400/80 leading-relaxed">
              {cap?.reason ?? "This Gate.io connection doesn't have futures permission enabled."}
              {" "}Every control below is real — it stays disabled until this is resolved. Nothing here fakes a fill.
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-1 min-h-0 overflow-hidden">
        <div className="flex-1 min-h-0" />

        <div className="w-[300px] flex-shrink-0 flex flex-col overflow-y-auto bg-[#0d1117] border-l border-white/[0.06]">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.06]">
            <span className="text-[10px] text-slate-600">Avail. (Futures)</span>
            <span className="text-sm font-black text-white">
              {capLoading ? "…" : canTrade ? `$${fmt(balance)}` : "—"}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 px-4 pt-3">
            <button
              onClick={() => setMarginMode(m => (m === "isolated" ? "cross" : "isolated"))}
              className="py-2 rounded-lg text-xs font-black bg-white/[0.04] border border-white/[0.08] text-slate-300 capitalize"
            >
              {marginMode}
            </button>
            <select
              value={leverage}
              onChange={e => setLeverage(Number(e.target.value))}
              className="py-2 rounded-lg text-xs font-black bg-white/[0.04] border border-white/[0.08] text-slate-300 text-center appearance-none cursor-pointer"
            >
              {LEVERAGE_PRESETS.map(l => <option key={l} value={l}>{l}X</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-0 border-b border-white/[0.06] mt-3">
            <button onClick={() => setPositionSide("long")}
              className={`py-3 font-black text-sm transition ${
                positionSide === "long" ? "bg-[#0ECB81] text-black" : "text-slate-600 hover:text-[#0ECB81] bg-transparent"
              }`}
            >
              Long
            </button>
            <button onClick={() => setPositionSide("short")}
              className={`py-3 font-black text-sm transition ${
                positionSide === "short" ? "bg-[#F6465D] text-white" : "text-slate-600 hover:text-[#F6465D] bg-transparent"
              }`}
            >
              Short
            </button>
          </div>

          <div className="flex flex-col gap-3 px-4 py-3">
            <div className="flex gap-0 bg-white/[0.04] rounded-lg p-0.5">
              <button onClick={() => setOrderType("MARKET")}
                className={`flex-1 py-1.5 rounded-md text-xs font-black transition ${orderType === "MARKET" ? "bg-white/10 text-white" : "text-slate-600 hover:text-slate-400"}`}
              >
                Market
              </button>
              <button onClick={() => setOrderType("LIMIT")}
                className={`flex-1 py-1.5 rounded-md text-xs font-black transition ${orderType === "LIMIT" ? "bg-white/10 text-white" : "text-slate-600 hover:text-slate-400"}`}
              >
                Limit
              </button>
            </div>

            {orderType === "LIMIT" && (
              <div>
                <label className="block text-[10px] text-slate-600 mb-1 uppercase tracking-wider">Limit Price (USDT)</label>
                <input type="number" value={limitPrice > 0 ? limitPrice : ""} placeholder={livePrice > 0 ? fmt(livePrice) : "Enter price"}
                  onChange={e => setLimitPrice(Number(e.target.value) || 0)}
                  className="w-full bg-white/[0.04] border border-white/[0.08] rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#0ea5e9]/40" />
              </div>
            )}

            <div>
              <label className="block text-[10px] text-slate-600 mb-1 uppercase tracking-wider">Margin (USDT)</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 text-sm font-mono">$</span>
                <input type="number" min={0} step={10} value={amountUsdt || ""}
                  onChange={e => setAmountUsdt(Math.max(0, Number(e.target.value) || 0))}
                  className="w-full bg-white/[0.04] border border-white/[0.08] rounded-lg pl-7 pr-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-[#0ea5e9]/40" />
              </div>
              <div className="text-[10px] text-slate-700 mt-0.5 font-mono">
                {notionalQty > 0 ? `≈ ${notionalQty.toFixed(6)} ${base} notional (${leverage}x)` : "—"}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-1">
              {[25, 50, 75, 100].map(pct => (
                <button key={pct} onClick={() => setPctOfBalance(pct)} disabled={balance === 0}
                  className="py-1 rounded text-[11px] font-black border border-white/[0.08] text-slate-600 hover:text-slate-400 hover:border-white/[0.15] disabled:opacity-30">
                  {pct}%
                </button>
              ))}
            </div>

            <div className="bg-white/[0.02] border border-white/[0.05] rounded-lg p-3 space-y-1.5 text-[11px]">
              <div className="flex justify-between"><span className="text-slate-600">Margin</span><span className="font-mono text-white">${fmt(marginRequired)}</span></div>
              <div className="flex justify-between"><span className="text-slate-600">Est. Liq. Price</span><span className="font-mono text-slate-500">— (set by exchange on fill)</span></div>
            </div>

            <div>
              <button onClick={() => setShowTpSl(v => !v)} className="flex items-center gap-2 text-[11px] font-black text-slate-500 hover:text-slate-300 transition">
                <span className={`w-3.5 h-3.5 rounded-sm border-2 flex items-center justify-center transition ${showTpSl ? "bg-[#0ea5e9] border-[#0ea5e9]" : "border-slate-700"}`}>
                  {showTpSl && <span className="block w-1.5 h-1 bg-white rounded-sm" />}
                </span>
                TP/SL
              </button>
              {showTpSl && (
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div>
                    <label className="block text-[9px] text-[#0ECB81] mb-1 uppercase tracking-wider">TP Trigger</label>
                    <input type="number" value={tpTrigger || ""} onChange={e => setTpTrigger(Number(e.target.value) || 0)}
                      className="w-full bg-white/[0.04] border border-[#0ECB81]/20 rounded-lg px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-[#0ECB81]/40" />
                  </div>
                  <div>
                    <label className="block text-[9px] text-[#F6465D] mb-1 uppercase tracking-wider">SL Trigger</label>
                    <input type="number" value={slTrigger || ""} onChange={e => setSlTrigger(Number(e.target.value) || 0)}
                      className="w-full bg-white/[0.04] border border-[#F6465D]/20 rounded-lg px-2 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-[#F6465D]/40" />
                  </div>
                </div>
              )}
            </div>

            {flash && (
              <div className={`flex items-start gap-1.5 rounded-lg text-[11px] px-3 py-2 ${flash.ok ? "bg-[#0ECB81]/10 border border-[#0ECB81]/20 text-[#0ECB81]" : "bg-[#F6465D]/10 border border-[#F6465D]/20 text-[#F6465D]"}`}>
                {flash.ok ? <CheckCircle2 size={12} className="shrink-0 mt-0.5" /> : <AlertTriangle size={12} className="shrink-0 mt-0.5" />}
                <span>{flash.text}</span>
              </div>
            )}

            <button
              onClick={() => void submitOrder()}
              disabled={!canTrade || busy || amountUsdt <= 0 || livePrice === 0}
              title={!canTrade ? (cap?.reason ?? "Futures trading unavailable") : undefined}
              className={`w-full py-4 rounded-xl font-black text-sm transition disabled:opacity-40 disabled:cursor-not-allowed ${
                positionSide === "long" ? "bg-[#0ECB81] hover:bg-[#0ab36e] text-black" : "bg-[#F6465D] hover:bg-[#d93a4e] text-white"
              }`}
            >
              {busy ? "Processing…" : positionSide === "long" ? `Open Long — ${displaySymbol}` : `Open Short — ${displaySymbol}`}
            </button>

            <div className="text-[9px] text-slate-700 text-center leading-relaxed">
              {isPaper ? "Paper" : "Gate.io"} Futures · isolated services/routes, no shared state with Spot execution
            </div>
          </div>
        </div>
      </div>

      <div className="h-[220px] flex-shrink-0 border-t border-white/[0.06] flex flex-col">
        <div className="flex items-center border-b border-white/[0.06] bg-[#0d1117] flex-shrink-0">
          {[
            { key: "positions" as const, label: "Positions", count: positions.length, icon: <TrendingUp size={11} /> },
            { key: "orders" as const, label: "Open Orders", count: orders.filter(o => o.status === "open" || o.status === "pending").length, icon: <Clock3 size={11} /> },
          ].map(({ key, label, count, icon }) => (
            <button key={key} onClick={() => setBottomTab(key)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-[11px] font-black uppercase tracking-wider border-b-2 transition ${
                bottomTab === key ? "border-[#0ea5e9] text-[#0ea5e9]" : "border-transparent text-slate-600 hover:text-slate-400"
              }`}
            >
              {icon}{label}
              {count > 0 && <span className="ml-0.5 px-1 rounded bg-white/10 text-[9px] font-black">{count}</span>}
            </button>
          ))}
        </div>

        <div className="flex-1 min-h-0 overflow-y-auto">
          {bottomTab === "positions" ? (
            positions.length === 0 ? (
              <div className="py-8 text-center text-slate-700 text-xs">
                {posLoading ? "Loading…" : canTrade ? "No open futures positions." : "Connect futures-enabled keys to see positions here."}
              </div>
            ) : (
              <table className="w-full text-[11px]">
                <thead>
                  <tr className="text-slate-600 text-left border-b border-white/[0.06]">
                    <th className="px-3 py-2 font-normal">Symbol</th>
                    <th className="px-3 py-2 font-normal">Side</th>
                    <th className="px-3 py-2 font-normal">Size</th>
                    <th className="px-3 py-2 font-normal">Entry</th>
                    <th className="px-3 py-2 font-normal">Mark</th>
                    <th className="px-3 py-2 font-normal">Liq.</th>
                    <th className="px-3 py-2 font-normal">uPnL</th>
                    <th className="px-3 py-2 font-normal"></th>
                  </tr>
                </thead>
                <tbody>
                  {positions.map(p => (
                    <tr key={`${p.symbol}-${p.side}`} className="border-b border-white/[0.04]">
                      <td className="px-3 py-2 font-black text-white">{p.symbol}</td>
                      <td className={`px-3 py-2 font-black ${p.side === "long" ? "text-[#0ECB81]" : "text-[#F6465D]"}`}>{p.side.toUpperCase()} {p.leverage}x</td>
                      <td className="px-3 py-2 font-mono text-slate-300">{p.contracts}</td>
                      <td className="px-3 py-2 font-mono text-slate-300">${fmt(p.entryPrice)}</td>
                      <td className="px-3 py-2 font-mono text-slate-300">${fmt(p.markPrice)}</td>
                      <td className="px-3 py-2 font-mono text-amber-500">{p.liquidationPrice ? `$${fmt(p.liquidationPrice)}` : "—"}</td>
                      <td className={`px-3 py-2 font-mono ${p.unrealizedPnl >= 0 ? "text-[#0ECB81]" : "text-[#F6465D]"}`}>{p.unrealizedPnl >= 0 ? "+" : ""}${fmt(p.unrealizedPnl)}</td>
                      <td className="px-3 py-2 text-right">
                        <button onClick={() => void closePosition(p)} disabled={closingSymbol === p.symbol}
                          className="text-[10px] font-black text-slate-500 hover:text-white border border-white/[0.1] rounded px-2 py-1 disabled:opacity-40">
                          {closingSymbol === p.symbol ? "…" : "Close"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )
          ) : orders.length === 0 ? (
            <div className="py-8 text-center text-slate-700 text-xs">{ordersLoading ? "Loading…" : "No futures orders yet."}</div>
          ) : (
            <table className="w-full text-[11px]">
              <thead>
                <tr className="text-slate-600 text-left border-b border-white/[0.06]">
                  <th className="px-3 py-2 font-normal">Symbol</th>
                  <th className="px-3 py-2 font-normal">Side</th>
                  <th className="px-3 py-2 font-normal">Type</th>
                  <th className="px-3 py-2 font-normal">Price</th>
                  <th className="px-3 py-2 font-normal">Qty</th>
                  <th className="px-3 py-2 font-normal">Status</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.orderId} className="border-b border-white/[0.04]">
                    <td className="px-3 py-2 font-black text-white">{o.symbol}</td>
                    <td className={`px-3 py-2 font-black ${o.positionSide === "long" ? "text-[#0ECB81]" : "text-[#F6465D]"}`}>{(o.positionSide ?? "—").toUpperCase()} {o.leverage ?? ""}x</td>
                    <td className="px-3 py-2 text-slate-400">{o.orderType}</td>
                    <td className="px-3 py-2 font-mono text-slate-300">{o.limitPrice ? `$${fmt(Number(o.limitPrice))}` : "Market"}</td>
                    <td className="px-3 py-2 font-mono text-slate-300">{o.quantity}</td>
                    <td className="px-3 py-2 text-slate-400">{o.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
